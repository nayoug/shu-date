const STORAGE_KEY = "shu-date-theme";
const THEME_OPTIONS = ["system", "light", "dark"];
const VALID_THEMES = new Set(THEME_OPTIONS);

let mediaQuery = null;
let currentTheme = "light";
let currentPreference = "system";
let mediaListenerAttached = false;

export function initializeTheme() {
  if (typeof window === "undefined" || typeof document === "undefined") {
    return currentTheme;
  }

  ensureMediaQuery();
  currentPreference = resolvePreference();
  applyTheme(resolveEffectiveTheme(currentPreference));
  attachMediaListener();
  return currentTheme;
}

export function setupThemeControls() {
  if (typeof document === "undefined") {
    return;
  }

  const buttons = Array.from(document.querySelectorAll("[data-theme-option]"));

  buttons.forEach((button) => {
    const preference = button.dataset.themeOption;
    if (button.dataset.themeBound === "true" || !VALID_THEMES.has(preference)) {
      return;
    }

    button.dataset.themeBound = "true";
    button.addEventListener("click", () => {
      if (currentPreference === preference) {
        return;
      }

      currentPreference = preference;
      persistTheme(currentPreference);
      applyTheme(resolveEffectiveTheme(currentPreference));
    });
  });

  updateThemeControls();
}

function ensureMediaQuery() {
  if (!mediaQuery && typeof window.matchMedia === "function") {
    mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
  }
}

function attachMediaListener() {
  if (!mediaQuery || mediaListenerAttached) {
    return;
  }

  const syncWithSystem = () => {
    if (currentPreference === "system") {
      applyTheme(resolveEffectiveTheme("system"));
      return;
    }

    updateThemeControls();
  };

  if (typeof mediaQuery.addEventListener === "function") {
    mediaQuery.addEventListener("change", syncWithSystem);
  } else if (typeof mediaQuery.addListener === "function") {
    mediaQuery.addListener(syncWithSystem);
  }

  mediaListenerAttached = true;
}

function resolvePreference() {
  const storedTheme = getStoredTheme();
  return VALID_THEMES.has(storedTheme) ? storedTheme : "system";
}

function resolveEffectiveTheme(preference = currentPreference) {
  if (preference === "light" || preference === "dark") {
    return preference;
  }

  return mediaQuery?.matches ? "dark" : "light";
}

function applyTheme(theme) {
  currentTheme = theme === "dark" ? "dark" : "light";

  if (typeof document === "undefined") {
    return;
  }

  document.documentElement.dataset.theme = currentTheme;
  document.documentElement.dataset.themePreference = currentPreference;
  document.documentElement.style.colorScheme = currentTheme;
  updateThemeControls();
}

function updateThemeControls() {
  if (typeof document === "undefined") {
    return;
  }

  document.querySelectorAll("[data-theme-option]").forEach((button) => {
    const preference = button.dataset.themeOption;
    const active = preference === currentPreference;
    const label = getPreferenceLabel(preference);

    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", String(active));
    button.setAttribute("aria-label", active ? `当前使用${label}` : `切换到${label}`);
    button.setAttribute("title", active ? `当前使用${label}` : `切换到${label}`);
  });

  const summary = getThemeSummary();
  document.querySelectorAll("[data-theme-summary]").forEach((node) => {
    node.textContent = summary;
  });
}

function getPreferenceLabel(preference) {
  if (preference === "dark") {
    return "深色模式";
  }

  if (preference === "light") {
    return "浅色模式";
  }

  return "跟随系统";
}

function getThemeSummary() {
  if (currentPreference === "system") {
    return `当前：跟随系统（${currentTheme === "dark" ? "深色" : "浅色"}）`;
  }

  return `当前：${getPreferenceLabel(currentPreference)}`;
}

function getStoredTheme() {
  try {
    return window.localStorage.getItem(STORAGE_KEY);
  } catch (error) {
    return null;
  }
}

function persistTheme(theme) {
  try {
    window.localStorage.setItem(STORAGE_KEY, theme);
  } catch (error) {
    // Ignore storage failures and keep the current session responsive.
  }
}
